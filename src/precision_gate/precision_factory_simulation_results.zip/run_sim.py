from __future__ import annotations
import json, hashlib
from pathlib import Path
import sys
sys.path.insert(0,'/mnt/data/precision_sim')
from precision_gate.pipeline import PrecisionPipeline, PrecisionGatePipeline, HumanReviewOutcome
from precision_gate.reporting import FinalReportBuilder, write_report_bundle
from precision_gate.contracts import canonical_json

OUT=Path('/mnt/data/precision_sim/results'); OUT.mkdir(exist_ok=True)
DEPTS=['procurement','production','quality','logistics','finance']
MONTHS=['2026-06','2026-07']
TYPES=['daily_log','transactions','quality_report','inventory','approvals']

def digest(s:str)->str: return hashlib.sha256(s.encode()).hexdigest()

def make_bundle(failure_mode=False):
    records=[]
    idx=0
    for d in DEPTS:
        for m in MONTHS:
            for typ in TYPES:
                idx += 1
                path=f'synthetic_shoe_factory/{d}/{m}/{typ}_{idx:03d}.txt'
                h=digest(path)
                extraction='ok'
                if failure_mode and idx in {17,34}: extraction='extraction_failed'
                if failure_mode and idx==42: extraction='ocr_failed'
                rec={
                    'file_name': path,
                    'raises_accusation': False,
                    'classification': 'fact_supported',
                    'classification_reasons':['document collected for external audit'],
                    'sha256': h,
                    'document': {'relative_path': path, 'sha256': h, 'extraction_status': extraction},
                    'extraction_status': extraction,
                    'artifact_type': 'ANALYTICAL_ARTIFACT',
                    'overall_outcome': 'PASS' if extraction=='ok' else 'PARTIAL_PASS',
                    'gates': {
                        'prescriptiveGate': {'status':'PASS','reason':'No prescriptive prohibition in synthetic fixture.','evidence':path},
                        'complianceGate': {'status':'PASS','reason':'Synthetic evidence is within audit scope.','evidence':path},
                        'traceabilityCheck': {'status':'PASS','reason':'Hash and source reference present.','evidence':path},
                        'maturityGate': {'status':'PASS','reason':'Fixture has sufficient metadata.','evidence':path},
                        'ledgerRuntimeCheck': {'status':'PASS','reason':'Synthetic ledger reference valid.','evidence':path},
                    },
                    'key_signals': {},
                }
                if failure_mode and idx==34:
                    rec['gates']['traceabilityCheck']={'status':'BLOCKED','reason':'Synthetic missing linkage injected for failure test.','evidence':path}
                records.append(rec)
    bundle={
        'audit_basis':'Synthetic external audit — shoe factory, 5 departments, June-July 2026',
        'generated_at':'2026-08-18T03:30:00Z',
        'mode':'strict',
        'accusation_set':[],
        'non_accusation_set':records,
        'accusation_set_count':0,
        'total_files_scanned':len(records),
        'classification_counts':{'fact_supported':len(records)},
    }
    return bundle

def run_compat(name,bundle):
    p=PrecisionPipeline()
    result=p.run(execution_id=name,tcria_bundle=bundle)
    data={
        'execution_id':result.execution_id,
        'event_count':len(result.events),
        'metrics':result.metrics.as_dict(),
        'alerts':list(result.alerts),
        'events':[e.to_dict() for e in result.events],
    }
    (OUT/f'{name}_compat.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
    return result

def run_full(name,bundle):
    p=PrecisionGatePipeline(name, created_at='2026-08-18T03:30:00Z')
    adap=p.ingest_tcria(bundle,source_id=f'{name}:tcria',source_ref='synthetic://shoe-factory/tcria-bundle')
    ctx=p.build_quinta_context(metadata={'case':'synthetic shoe factory external audit','documents':50})
    decision={
        'schema_version':'1.0','execution_id':name,'status':'approved','confidence':1.0,
        'breakdown':{k:1.0 for k in ['integrity','traceability','evidence_support','logical_consistency','resolution']},
        'findings':[],'remaining_uncertainties':[],'human_review_required':False,
        'evaluated_verifiers':['integrity','traceability','evidence_support','logical_consistency','resolution'],
        'execution_context_sha256':p.quinta_context_sha256,
    }
    q=p.record_quinta_decision(decision,source_ref='synthetic://quinta/decision')
    h=p.record_human_review(review_id='review-001',reviewer_ref='synthetic-auditor',outcome=HumanReviewOutcome.ACCEPTED,summary='Synthetic human review accepted the audited package.',support_refs=[q.event_id])
    final=p.finalize()
    data={'finalization':final.to_dict(),'event_count':len(p.trail.events),'chain_verification':p.trail.verify().__dict__,'events':[e.to_dict() for e in p.trail.events]}
    (OUT/f'{name}_full.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
    # Generate report bundle from finalized pipeline using direct builder
    report=FinalReportBuilder().build(p)
    (OUT/f'{name}_final_report.json').write_text(report.report_json,encoding='utf8')
    (OUT/f'{name}_final_report.md').write_text(report.report_markdown,encoding='utf8')
    return p, final

for mode in ['clean','failure']:
    bundle=make_bundle(failure_mode=(mode=='failure'))
    (OUT/f'factory_{mode}_tcria_bundle.json').write_text(json.dumps(bundle,ensure_ascii=False,indent=2),encoding='utf8')
    compat=run_compat(f'shoe-factory-{mode}',bundle)
    p,final=run_full(f'shoe-factory-{mode}',bundle)
    print(mode, 'compat_events=', len(compat.events), 'full_events=', len(p.trail.events), 'released=', final.released, 'chain_valid=', p.trail.verify().valid, 'alerts=', len(compat.alerts))
