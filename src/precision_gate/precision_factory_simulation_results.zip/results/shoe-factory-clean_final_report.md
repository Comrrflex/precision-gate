# Precision Gate Final Report

- **Trace:** `shoe-factory-clean`
- **Generated:** `2026-08-18T03:42:10Z`
- **Released to human/institutional flow:** `True`
- **All released facts approved by their source gates:** `True`
- **Quinta Ordem status:** `approved`
- **Human outcome:** `accepted`

> This is a non-authoritative operational reference. The final decision remains human.

## Custody verification

- **Valid:** `True`
- **Events:** `304`
- **Final chain SHA-256:** `3b2c61ebea99ff6f9018a4c1585c0d8aa729d108f480cecf2800b30692955dbf`

## Best-supported operational reading

- **Support tier:** `gate_verified`
- **Events:** `shoe-factory-clean:tcria:non_accusation_set:0:record`, `shoe-factory-clean:tcria:non_accusation_set:1:record`, `shoe-factory-clean:tcria:non_accusation_set:2:record`, `shoe-factory-clean:tcria:non_accusation_set:3:record`, `shoe-factory-clean:tcria:non_accusation_set:4:record`, `shoe-factory-clean:tcria:non_accusation_set:5:record`, `shoe-factory-clean:tcria:non_accusation_set:6:record`, `shoe-factory-clean:tcria:non_accusation_set:7:record`, `shoe-factory-clean:tcria:non_accusation_set:8:record`, `shoe-factory-clean:tcria:non_accusation_set:9:record`, `shoe-factory-clean:tcria:non_accusation_set:10:record`, `shoe-factory-clean:tcria:non_accusation_set:11:record`, `shoe-factory-clean:tcria:non_accusation_set:12:record`, `shoe-factory-clean:tcria:non_accusation_set:13:record`, `shoe-factory-clean:tcria:non_accusation_set:14:record`, `shoe-factory-clean:tcria:non_accusation_set:15:record`, `shoe-factory-clean:tcria:non_accusation_set:16:record`, `shoe-factory-clean:tcria:non_accusation_set:17:record`, `shoe-factory-clean:tcria:non_accusation_set:18:record`, `shoe-factory-clean:tcria:non_accusation_set:19:record`, `shoe-factory-clean:tcria:non_accusation_set:20:record`, `shoe-factory-clean:tcria:non_accusation_set:21:record`, `shoe-factory-clean:tcria:non_accusation_set:22:record`, `shoe-factory-clean:tcria:non_accusation_set:23:record`, `shoe-factory-clean:tcria:non_accusation_set:24:record`, `shoe-factory-clean:tcria:non_accusation_set:25:record`, `shoe-factory-clean:tcria:non_accusation_set:26:record`, `shoe-factory-clean:tcria:non_accusation_set:27:record`, `shoe-factory-clean:tcria:non_accusation_set:28:record`, `shoe-factory-clean:tcria:non_accusation_set:29:record`, `shoe-factory-clean:tcria:non_accusation_set:30:record`, `shoe-factory-clean:tcria:non_accusation_set:31:record`, `shoe-factory-clean:tcria:non_accusation_set:32:record`, `shoe-factory-clean:tcria:non_accusation_set:33:record`, `shoe-factory-clean:tcria:non_accusation_set:34:record`, `shoe-factory-clean:tcria:non_accusation_set:35:record`, `shoe-factory-clean:tcria:non_accusation_set:36:record`, `shoe-factory-clean:tcria:non_accusation_set:37:record`, `shoe-factory-clean:tcria:non_accusation_set:38:record`, `shoe-factory-clean:tcria:non_accusation_set:39:record`, `shoe-factory-clean:tcria:non_accusation_set:40:record`, `shoe-factory-clean:tcria:non_accusation_set:41:record`, `shoe-factory-clean:tcria:non_accusation_set:42:record`, `shoe-factory-clean:tcria:non_accusation_set:43:record`, `shoe-factory-clean:tcria:non_accusation_set:44:record`, `shoe-factory-clean:tcria:non_accusation_set:45:record`, `shoe-factory-clean:tcria:non_accusation_set:46:record`, `shoe-factory-clean:tcria:non_accusation_set:47:record`, `shoe-factory-clean:tcria:non_accusation_set:48:record`, `shoe-factory-clean:tcria:non_accusation_set:49:record`
- **Conflict:** `False`

## Informational states

| State | Count |
|---|---:|
| `fact_supported` | 50 |
| `original_preserved` | 252 |
| `pending` | 1 |
| `released` | 1 |

## Coherence alerts

- None.

## Remaining uncertainties

- None recorded.

## Human review

- **Recorded review events:** 1
- **Review still required:** `False`

## Validation

- No labeled validation set was attached to this execution.

The 95% target, when used, is an observed validation threshold over labeled cases.
It is not a promise of absolute truth or autonomous decision correctness.
