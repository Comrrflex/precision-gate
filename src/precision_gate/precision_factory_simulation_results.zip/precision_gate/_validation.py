from __future__ import annotations
from copy import deepcopy
from hashlib import sha256
from collections.abc import Mapping
from typing import Any
from .contracts import canonical_json, validate_sha256

def strict_snapshot(value: Mapping[str, Any], *, name: str = 'value') -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f'{name} must be a mapping.')
    snap = deepcopy(dict(value))
    canonical_json(snap)  # ensure serializable
    return snap

def canonical_sha256(value: Any) -> str:
    return sha256(canonical_json(value).encode('utf-8')).hexdigest()

def require_mapping(value: Mapping[str, Any], key: str) -> Mapping[str, Any]:
    v = value.get(key)
    if not isinstance(v, Mapping): raise ValueError(f'{key} must be a mapping.')
    return v

def optional_mapping(value: Mapping[str, Any], key: str) -> Mapping[str, Any]:
    v = value.get(key, {})
    if v is None: return {}
    if not isinstance(v, Mapping): raise ValueError(f'{key} must be a mapping.')
    return v

def require_mapping_list(value: Mapping[str, Any], key: str) -> list[Mapping[str, Any]]:
    v = value.get(key)
    if not isinstance(v, list) or not all(isinstance(x, Mapping) for x in v):
        raise ValueError(f'{key} must be a list of mappings.')
    return v

def require_text(value: Mapping[str, Any], key: str) -> str:
    v = value.get(key)
    if not isinstance(v, str) or not v.strip(): raise ValueError(f'{key} must be non-empty text.')
    return v.strip()

def optional_text(value: Mapping[str, Any], key: str) -> str | None:
    v = value.get(key)
    if v is None: return None
    if not isinstance(v, str): raise ValueError(f'{key} must be text or null.')
    return v.strip() or None

def require_bool(value: Mapping[str, Any], key: str) -> bool:
    v = value.get(key)
    if not isinstance(v, bool): raise ValueError(f'{key} must be boolean.')
    return v

def require_non_negative_int(value: Mapping[str, Any], key: str) -> int:
    v = value.get(key)
    if not isinstance(v, int) or isinstance(v, bool) or v < 0: raise ValueError(f'{key} must be a non-negative integer.')
    return v
